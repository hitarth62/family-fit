# Family Fit (install on all phones, no PC needed)

## Step 1: Server (once, ~5 min, free)
1. MongoDB Atlas: create a free cluster, add a database user, allow access from anywhere (0.0.0.0/0), copy the connection string.
2. Put this whole folder on GitHub (new repo, branch `main`).
3. Render.com > New Web Service > your repo. Root directory `server`, build `npm install`, start `node server.js`.
   Env vars: MONGODB_URI, JWT_SECRET (any long random text).
4. Copy your Render URL, e.g. https://family-fit-abc.onrender.com

## Step 2: Put the server URL in the app
Either edit `YOUR-SERVER.onrender.com` near the top of `app/www/index.html`, or just type the address into the "Server address" box on the first screen (it is remembered).

## Step 3: Build the APK
GitHub > Actions > "Build APK" > Run workflow. When it finishes, open the run, download the artifact `FamilyFit-apk`, unzip, install `app-debug.apk` on each phone (allow "install unknown apps").
Updates: run the workflow again and install the new APK over the old one. Data stays because the signing key is fixed and all data lives on the server.

## Using it
You tap "Start family" (you become admin), add mom and dad in the Family tab, and share the family code. They sign in with code + name + PIN.
Note: free Render sleeps after inactivity, so the first open can take ~30 seconds.
